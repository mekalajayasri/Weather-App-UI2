const apiKey = '4677d4a42616d0bebc02f3eb3485255c';

// Retrieve username (fallbacks for both login and signup storage keys)
const userName = localStorage.getItem("username") || localStorage.getItem("registeredName");

// Display welcome message
const welcomeMessage = document.getElementById("welcome-message");
if (userName) {
    welcomeMessage.textContent = `👋 Welcome, ${userName}!`;
} else {
    welcomeMessage.textContent = "👋 Welcome to the Weather App!";
}

// Logout functionality
const logoutBtn = document.getElementById("logout-btn");
if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
        localStorage.removeItem("username");
        localStorage.removeItem("registeredName");
        localStorage.removeItem("token");
        window.location.href = "/login";
    });
}

// Initialize map (default view to India)
const map = L.map('map').setView([20, 78], 4);

// Load OpenStreetMap tiles
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);

// Map click event to fetch weather
map.on('click', async function (e) {
    const lat = e.latlng.lat;
    const lon = e.latlng.lng;
    getWeatherByCoords(lat, lon);
});

// Fetch weather by city name
async function getWeatherByCity() {
    const city = document.getElementById('city').value;
    if (!city) return alert("Please enter a city!");

    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${apiKey}`;

    try {
        const response = await fetch(url);
        if (!response.ok) throw new Error("City not found");
        const data = await response.json();

        updateWeatherUI(data);
        map.setView([data.coord.lat, data.coord.lon], 10);
    } catch (error) {
        alert("Error: " + error.message);
    }
}

// Fetch weather using lat/lon
async function getWeatherByCoords(lat, lon) {
    const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&units=metric&appid=${apiKey}`;

    try {
        const response = await fetch(url);
        if (!response.ok) throw new Error("Weather data not found");
        const data = await response.json();

        updateWeatherUI(data);
        map.setView([lat, lon], 10);
    } catch (error) {
        alert("Error: " + error.message);
    }
}

// Update UI elements with weather data
function updateWeatherUI(data) {
    document.querySelector('.temp').textContent = `${data.main.temp}°C`;
    document.querySelector('.city').textContent = data.name;
    document.getElementById('humidity').textContent = data.main.humidity;
    document.getElementById('wind').textContent = data.wind.speed;
}
